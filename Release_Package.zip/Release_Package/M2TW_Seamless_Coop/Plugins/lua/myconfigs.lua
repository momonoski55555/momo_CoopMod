--1 or 0, enable console or not
--console shortcut - ctrl+~
enableConsole=1;
--1 if you want the game to crash on an error in your script (Lua exception). You will still receive a message detailing the error, but closing it will also close the game.
terminateAtLuaException=0;